# Doctor Panel

[Functional Requirements](Functional%20Requirements%202471a3cd7f81819098acdaa514b90132.csv)

[Non-Functional Requirements](Non-Functional%20Requirements%2026e1a3cd7f8180d58a8ec84512fa7b3a.csv)
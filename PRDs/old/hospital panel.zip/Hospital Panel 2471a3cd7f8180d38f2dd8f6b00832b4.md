# Hospital Panel

[Functional Requirements](Functional%20Requirements%202471a3cd7f8181c0a242c6fad7e96634.csv)

[Non-Functional Requirements](Non-Functional%20Requirements%2026e1a3cd7f8180129f50c3a9cea1ad6b.csv)